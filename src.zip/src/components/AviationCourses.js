import React from 'react';
import { motion } from 'framer-motion';
import { Users, Star, Ticket, MessageCircle } from 'lucide-react';
const CourseCard = ({ icon: Icon, title, description, targetId }) => (
  <motion.div
    initial={{ opacity: 0, y: 50 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
    whileHover={{ scale: 1.05 }}
    className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow"
  >
    <Icon className="w-12 h-12 text-blue-600 mx-auto mb-4" />
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-gray-600 mb-4">{description}</p>
    <a href={`#${targetId}`} className="text-blue-600 hover:underline" aria-label={`Learn more about ${title}`}>
      Learn More →
    </a>
  </motion.div>
);

const AviationCourses = () => (
  <section id="aviation-courses" className="bg-gray-100 py-16">
    <div className="container mx-auto px-4">
      <motion.h2
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-3xl font-bold text-center text-blue-600 mb-12"
      >
        Aviation Courses
      </motion.h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <CourseCard
          icon={Users}
          title="Air Hostesses"
          description="Training for aspiring air hostesses, focusing on service excellence."
          targetId="air-hostesses"
        />
        <CourseCard
          icon={Star}
          title="Flight Pursers"
          description="Comprehensive training for flight pursers, including leadership skills."
          targetId="flight-pursers"
        />
        <CourseCard
          icon={Ticket}
          title="Ticketing & Reservation"
          description="Learn the essentials of ticketing systems and reservation management."
          targetId="ticketing-reservation"
        />
        <CourseCard
          icon={MessageCircle}
          title="Customer Relations & Personality Development"
          description="Enhance skills in communication and relationship management alongside personal development."
          targetId="customer-relations"
        />
      </div>
    </div>
  </section>
);

export default AviationCourses;
