// Navigation.js
import React, { useState } from 'react';
import { motion } from 'framer-motion';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white py-4 shadow-md">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="text-2xl font-bold text-blue-600"
        >
          AVIATION
        </motion.div>

        {/* Hamburger Menu Icon - Visible on small screens */}
        <motion.div
          className="sm:hidden"
          onClick={() => setIsOpen(!isOpen)}
          whileTap={{ scale: 0.9 }}
        >
          <div className="space-y-2 cursor-pointer">
            <div className="w-8 h-0.5 bg-blue-600"></div>
            <div className="w-8 h-0.5 bg-blue-600"></div>
            <div className="w-8 h-0.5 bg-blue-600"></div>
          </div>
        </motion.div>

        {/* Navigation Links - Hidden on small screens */}
        <ul
          className={`flex-col sm:flex sm:flex-row sm:space-x-6 space-y-4 sm:space-y-0 absolute sm:static left-0 top-full w-full sm:w-auto sm:items-center transition-all duration-500 ease-in-out bg-white sm:bg-transparent sm:translate-x-0 ${
            isOpen ? 'translate-x-0' : 'translate-x-full sm:flex'
          }`}
        >
          {['Home', 'About Us', 'Courses', 'Memories'].map((item, index) => (
            <motion.li
              key={item}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <a
                href={
                  item === 'Home'
                    ? '#'
                    : item === 'Courses'
                    ? '#aviation-courses'
                    : `#${item.toLowerCase().replace(' ', '-')}`
                }
                className="text-gray-700 hover:text-blue-600 block px-4 py-2"
              >
                {item}
              </a>
            </motion.li>
          ))}
        </ul>

        <motion.a
          href="#contact"
          className="hidden sm:inline-block bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition duration-300"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Contact Us
        </motion.a>
      </div>
    </nav>
  );
};

export default Navigation;
