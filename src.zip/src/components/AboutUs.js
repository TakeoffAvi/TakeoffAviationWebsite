// AboutUs.js
import React from 'react';
import { motion } from 'framer-motion';

const AboutUs = () => (
  <section id="about-us" className="container mx-auto px-4 py-16">
    <div className="flex flex-wrap items-center justify-between">
      {/* Left Section: Text */}
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full md:w-5/12 lg:w-1/2 pr-8 mb-8 md:mb-0"
      >
<h2 className="text-3xl font-bold text-blue-700 mb-4">
  WELCOME TO TAKE OFF AVIATION ACADEMY
</h2>

        <h3 className="text-2xl text-gray-700 mb-4">YOUR GATEWAY TO A SKY-HIGH CAREER!</h3>
        <p className="text-lg text-gray-600 leading-relaxed mb-6">
        At Take Off Aviation Academy, we turn your passion for aviation 
into a rewarding career. Our comprehensive  training  program 
equips you with the skills, knowledge, and  confidence to excel 
as a cabin crew member or air hostess. Join us and begin  your 
journey towards a dynamic and exciting career in the skies!
        </p>
        <ul className="grid grid-cols-2 gap-4 text-lg">
          {[
            'Professional Teachers',
            'Certified Programs',
            'Quality Research',
            'Broad Capabilities',
            'Trusted Expertise',
            'High Integrity',
            'Best Courses Offered',
            'Proven Track Record',
          ].map((item, index) => (
            <motion.li
              key={item}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center text-gray-700"
            >
              <svg className="w-5 h-5 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
              {item}
            </motion.li>
          ))}
        </ul>
      </motion.div>

      {/* Right Section: Image */}
      <motion.div
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full md:w-7/12 lg:w-1/2"
      >
        <div className="box">
          <motion.img
            src={`${process.env.PUBLIC_URL}/images/about.jpg`} // Path to your image in the public folder
            alt="About Takeoff Aviation"
            className="rounded-lg shadow-lg w-full h-auto object-cover" // Updated to cover the grid better
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </motion.div>
    </div>
  </section>
);

export default AboutUs;
